# 🎧 OffRadar — Extension Chrome

Version extension (Chrome / Edge / Brave / Chromium) de l'outil de découverte musicale.
Tout tourne **dans le navigateur** : aucune installation de serveur, chaque utilisateur
utilise son propre compte développeur Spotify (contourne la limite de 5 utilisateurs).

## Installer en local (mode développeur)

1. Ouvrir **chrome://extensions**
2. Activer **« Mode développeur »** (en haut à droite)
3. Cliquer **« Charger l'extension non empaquetée »** → choisir ce dossier `extension/`
4. Une icône de disque vert apparaît dans la barre d'outils → cliquer dessus :
   l'app s'ouvre dans un onglet.

## Configuration (1ʳᵉ fois, écran d'onboarding)

Au premier lancement, l'app affiche un écran de configuration :

1. **Créer une app** sur le [Spotify Developer Dashboard](https://developer.spotify.com/dashboard)
   (ou réutiliser une app existante).
2. Dans les **Settings** de l'app Spotify → **Redirect URIs**, ajouter **exactement**
   l'URL affichée par l'onboarding (de la forme
   `https://<id-extension>.chromiumapp.org/`) puis **Save**.
3. Copier le **Client ID** de l'app et le coller dans le champ de l'onboarding →
   **Enregistrer**.
4. Cliquer **« Se connecter à Spotify »** → autoriser → c'est prêt.

> ⚠️ L'**identifiant de l'extension** (et donc la Redirect URI) :
> - reste **stable** tant que le dossier n'est pas déplacé (mode non empaqueté) ;
> - **changera** une fois publiée sur le Chrome Web Store → il faudra alors mettre à jour
>   la Redirect URI dans Spotify (l'onboarding affiche toujours la bonne URL à utiliser).

## Notes techniques

- **OAuth PKCE** (pas de client secret stocké — sûr pour une extension).
- **Clé Last.fm embarquée** (partagée) : les appels partent de l'IP de chaque utilisateur,
  donc la limite Last.fm (5 req/s/IP) n'est pas un goulot.
- Données **isolées par compte Spotify** dans `chrome.storage.local`
  (clé `histo_<userId>`).
- Jaquettes générées via **Canvas** (pas de dépendance native).
- Manifest V3 : aucun code distant, aucun gestionnaire d'événement inline (conforme CSP).

## Algorithme

Identique à la version serveur : lecture du goût (top artistes/titres + écoutes récentes),
découverte via Last.fm (artistes similaires + tags d'ambiance/style), vérification Spotify,
filtres (ambiance = exclusion de genres, notoriété = popularité artiste, styles inclus/exclus),
diversité (1 titre/artiste), élargissement borné si vivier insuffisant, apprentissage des
suppressions, historique des 10 dernières playlists.
