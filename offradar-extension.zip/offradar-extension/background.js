// Service worker minimal : ouvre l'app dans un onglet au clic sur l'icône.
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL('app.html') });
});
