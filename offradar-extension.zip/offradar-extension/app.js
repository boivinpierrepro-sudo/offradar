'use strict';

// Alias cross-navigateur : `browser` (Firefox, APIs en promesses) sinon `chrome` (Chrome MV3).
const api = (typeof browser !== 'undefined') ? browser : chrome;

// =====================================================================
//  Constantes
// =====================================================================
const LASTFM_API_KEY = '616551dc292f2fb23715b202bdc56176';
// URL de la page d'accueil de partage (GitHub Pages). Laisser vide = partager le
// lien Spotify brut. Ex. : 'https://monpseudo.github.io/offradar/'
const PAGE_PARTAGE = 'https://getoffradar.com/';
const SCOPES = [
  'user-top-read', 'user-read-recently-played',
  'playlist-modify-private', 'playlist-modify-public',
  'playlist-read-private', 'ugc-image-upload',
].join(' ');
const MAX_HISTO = 10;
const POP_SEUILS = [25, 42, 58, 75, 100];
const FAM_BIAIS = [0.25, 0.6, 1, 2, 4]; // niveau 1 (audacieux) → 5 (proche des goûts)
// Paliers de l'historique de référence : 1 jour (écoute récente) → tout (top long terme)
const HISTO_STEPS = [{ jours: 1 }, { range: 'short_term' }, { range: 'medium_term' }, { range: 'long_term' }];
const DECENNIES = [['< 1960', 0], ['60s', 1960], ['70s', 1970], ['80s', 1980], ['90s', 1990], ['2000s', 2000], ['2010s', 2010], ['2020s', 2020]];
const decennieDe = (annee) => (annee && annee < 1960 ? 0 : Math.floor(annee / 10) * 10);

const G_AGRESSIFS = ['noise', 'hardcore', 'gabber', 'speedcore', 'breakcore', 'grindcore', 'death metal', 'thrash', 'metalcore', 'black metal', 'power electronics', 'harsh', 'hardstyle', 'aggrotech'];
const G_INTENSES = ['hard techno', 'dubstep', 'drum and bass', 'industrial', 'trap', 'crunk'];
const G_CALMES = ['ambient', 'sleep', 'meditation', 'new age', 'drone', 'lullaby', 'slowcore'];

const AMBIANCES = {
  '': { titre: 'Découvertes', tags: [], exclure: [] },
  bosser: { titre: 'Focus', tags: ['instrumental', 'post-rock', 'downtempo', 'idm', 'electronic', 'chillout'], exclure: [...G_AGRESSIFS] },
  relaxation: { titre: 'Relaxation', tags: ['modern classical', 'neoclassical', 'contemporary classical', 'ambient', 'piano', 'minimalism'], exclure: [...G_AGRESSIFS, ...G_INTENSES, 'metal', 'punk', 'dance', 'techno', 'house', 'pop', 'rap'] },
  chill: { titre: 'Chill', tags: ['chillout', 'downtempo', 'trip-hop', 'dream pop', 'lo-fi', 'chillwave'], exclure: [...G_AGRESSIFS, ...G_INTENSES, 'metal', 'hard techno'] },
  matin: { titre: 'Matin doux', tags: ['acoustic', 'folk', 'indie folk', 'indie pop', 'singer-songwriter'], exclure: [...G_AGRESSIFS, ...G_INTENSES, 'metal', 'hard techno'] },
  melancolie: { titre: 'Mélancolie', tags: ['melancholy', 'slowcore', 'indie folk', 'singer-songwriter', 'sadcore', 'ambient'], exclure: [...G_AGRESSIFS, 'dance', 'hardstyle', 'happy hardcore', 'party'] },
  romantique: { titre: 'Romantique', tags: ['soul', 'r&b', 'quiet storm', 'smooth soul', 'ballad'], exclure: [...G_AGRESSIFS, ...G_INTENSES, 'techno', 'drone'] },
  jazz: { titre: 'Jazz feutré', tags: ['jazz', 'nu jazz', 'bossa nova', 'soul jazz', 'lounge', 'cool jazz'], exclure: [...G_AGRESSIFS, 'metal', 'punk', 'hardstyle'] },
  recevoir: { titre: 'Apéro', tags: ['funk', 'soul', 'disco', 'nu disco', 'lounge', 'groove'], exclure: [...G_AGRESSIFS, 'drone', 'sleep', 'meditation'] },
  roadtrip: { titre: 'Road trip', tags: ['indie rock', 'classic rock', 'pop rock', 'alternative rock', 'americana'], exclure: ['noise', 'gabber', 'speedcore', 'breakcore', 'grindcore', 'power electronics', 'harsh', 'sleep', 'meditation', 'drone'] },
  ete: { titre: 'Été', tags: ['tropical', 'reggae', 'surf rock', 'indie pop', 'afrobeats'], exclure: [...G_AGRESSIFS, 'drone', 'sleep', 'meditation', 'industrial'] },
  sport: { titre: 'Sport', tags: ['dance', 'techno', 'house', 'drum and bass', 'workout', 'hip-hop'], exclure: [...G_CALMES] },
  soiree: { titre: 'Soirée', tags: ['house', 'techno', 'disco', 'electro', 'dance'], exclure: [...G_CALMES, 'noise', 'power electronics'] },
};
const TITRES_EN = { '': 'Discoveries', bosser: 'Focus', relaxation: 'Relaxation', chill: 'Chill', matin: 'Gentle morning', melancolie: 'Melancholy', romantique: 'Romantic', jazz: 'Late-night jazz', recevoir: 'Drinks', roadtrip: 'Road trip', ete: 'Summer', sport: 'Sport', soiree: 'Party' };
const PREFIXE_NOM = { fr: 'Découvertes', en: 'Discoveries' };
const LABEL_JAQUETTE = { fr: 'DÉCOUVERTES', en: 'DISCOVERIES' };
const titreAmb = (cle, l) => (l === 'en' ? TITRES_EN[cle] || AMBIANCES[cle].titre : AMBIANCES[cle].titre);

const TAGS_NON_GENRES = ['seen live', 'favorites', 'favourite', 'favorite', 'fav', 'love', 'beautiful', 'awesome', 'cool', 'sexy', 'catchy', 'good', 'amazing', 'best', 'my music', 'albums i own', 'spotify', 'under 2000 listeners', 'female vocalists', 'male vocalists', 'female vocalist', 'male vocalist', 'singer-songwriter', 'bookmark', 'mp3', 'radio', 'guitar', 'piano'];
const estGenre = (nom) => { const n = nom.toLowerCase(); if (/\d0s|\d{4}/.test(n)) return false; return !TAGS_NON_GENRES.some((x) => n === x || n.includes(x)); };

// Icônes SVG inline (pas de dépendance externe, conforme MV3)
const ICON = {
  check: '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zm-1.2 14.3l-3.5-3.5 1.4-1.4 2.1 2.1 4.6-4.6 1.4 1.4z"/></svg>',
  spinner: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 3a9 9 0 109 9"><animateTransform attributeName="transform" type="rotate" from="0 12 12" to="360 12 12" dur="0.9s" repeatCount="indefinite"/></path></svg>',
  warn: '<svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor"><path d="M12 2L1 21h22zm0 6l.9 7h-1.8zm0 9.5a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z"/></svg>',
  trash: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/></svg>',
  restore: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 109-9 9 9 0 00-7 3.3M3 3v4h4"/></svg>',
  caret: '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M12 15l-5-5h10z"/></svg>',
  spotify: '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zm4.6 14.4a.6.6 0 01-.86.2c-2.35-1.44-5.3-1.76-8.79-.96a.62.62 0 11-.28-1.2c3.8-.87 7.07-.5 9.7 1.1.3.18.4.57.23.86zm1.23-2.74a.78.78 0 01-1.07.26c-2.69-1.65-6.79-2.13-9.97-1.17a.78.78 0 11-.45-1.49c3.63-1.1 8.15-.56 11.23 1.33.36.22.48.7.26 1.07zm.1-2.85C14.8 8.06 9.5 7.86 6.45 8.79a.94.94 0 11-.54-1.8c3.5-1.06 9.35-.85 13.04 1.34a.94.94 0 01-.96 1.62z"/></svg>',
  signout: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/></svg>',
  share: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/></svg>',
};

// =====================================================================
//  Traductions
// =====================================================================
const I18N = {
  fr: {
    titre: 'OffRadar',
    sousTitre: 'Basé sur votre historique — artistes différents, plus pointus, qui apprennent de vos suppressions.',
    connecte: 'Connecté à Spotify', seConnecter: 'Se connecter à Spotify', deconnexion: 'Se déconnecter',
    reglages: 'Modifier la configuration',
    onbTitre: 'Configuration (une seule fois, ~3 min)',
    onbIntro: "Cette extension utilise votre propre compte développeur Spotify (gratuit) :",
    onbEtape1: 'Ouvrez le Spotify Developer Dashboard, puis cliquez sur « Create app ».',
    onbEtape2: 'App name : « OffRadar » (ce que vous voulez) · App description : « perso ».',
    onbEtape3: 'Cochez « Web API » dans les types d\'API proposés.',
    onbEtape4: 'Dans « Redirect URIs », collez cette URL puis cliquez sur « Add » :',
    onbEtape5: 'Cliquez sur « Save » tout en bas (étape souvent oubliée !).',
    onbUserMgmt: 'Dans l\'onglet « User Management » de l\'app, ajoutez l\'e-mail de votre compte Spotify (obligatoire en mode développeur).',
    onbEtape6: 'Copiez le « Client ID » de l\'app et collez-le ci-dessous :',
    loginErrChargement: 'Spotify n\'a pas pu ouvrir la page d\'autorisation. Vérifiez que la Redirect URI (voir « Modifier la configuration ») est bien ajoutée ET enregistrée (« Save ») dans votre app Spotify, et que le Client ID est correct.',
    loginErrGenerique: (e) => `La connexion a échoué : ${e}`,
    loginAnnule: 'Connexion interrompue. Si vous n\'avez pas annulé volontairement, vérifiez que la Redirect URI est bien ajoutée ET enregistrée (« Save ») dans votre app Spotify, puis réessayez.',
    onbCopier: 'Copier', onbCopie: 'Copié ✓', onbEnregistrer: 'Enregistrer',
    taille: 'Taille de la playlist', segNombre: 'Nombre de titres', segDuree: "Durée d'écoute",
    nbMorceaux: 'Nombre de morceaux', dureeCible: 'Durée cible',
    uTitres: (n) => `${n} titres`, uMin: (n) => `${n} min`,
    ambianceLabel: "Ambiance d'écoute", notoriete: 'Niveau de notoriété',
    popDesactive: "Critère désactivé — la notoriété n'est pas prise en compte.",
    styles: 'Styles musicaux',
    stylesAide: "Cliquez pour inclure ou exclure des styles. Vos styles habituels sont pré-sélectionnés ; ajoutez-en d'autres pour explorer.",
    stylesHisto: 'Styles de votre historique', stylesPop: 'Styles populaires', stylesAutres: 'Autres styles',
    aucunStyle: 'Aucun style détecté dans votre écoute.', chargement: 'Chargement…',
    voirPlus: 'Voir plus', voirMoins: 'Voir moins',
    stylesDesactive: 'Critère désactivé — tous les styles sont possibles.',
    epoque: 'Époque', epoqueAide: 'Choisissez les décennies à inclure (selon l\'année de sortie).',
    epoqueDesactive: 'Critère désactivé — toutes les époques sont possibles.',
    familiarite: 'Dose de familiarité', famDesactive: 'Critère désactivé — découverte équilibrée par défaut.',
    famLabels: ['Très audacieux — loin de mes goûts', 'Audacieux', 'Équilibré', 'Proche de mes goûts', 'Très proche de mes goûts'],
    explicite: 'Exclure les titres explicites', expliciteAide: 'Activé : ne garde que des titres « clean » (sans contenu explicite).',
    histoRef: 'Historique de référence', generer: 'Générer une nouvelle playlist',
    recherche: 'Recherche de pépites en cours… (~15–30 s)',
    chargementMsgs: ['Analyse de votre écoute…', 'Exploration de nouveaux artistes…', 'Sélection des pépites…', 'Création de la playlist…'],
    ouvrir: 'Ouvrir dans Spotify', supprimer: 'Supprimer', partager: 'Partager', partageCopie: 'Lien copié ✓',
    partageTexte: (nom, url) => `🎧 ${nom}\n${url}\n\nPlaylist créée avec OffRadar.`,
    partagePromo: 'Playlist créée avec OffRadar',
    jaquetteErr: (e) => `Jaquette non posée : ${e}`,
    assoupliMsg: 'Vos filtres étaient un peu trop restreints : je les ai légèrement élargis pour compléter la playlist.',
    compte: (n, m) => `${n} titres · ~${m} min`,
    bibliothequeInfo: 'Playlist ajoutée à ta bibliothèque Spotify. Sur l\'app mobile, elle peut mettre un instant à apparaître — rouvre l\'app si besoin.',
    renvoyer: 'Renvoyer dans Spotify', restauration: 'Restauration…', suppression: 'Suppression…',
    confirmSuppr: 'Supprimer cette playlist de votre Spotify ? (action définitive)',
    histoTitre: 'Historique (10 dernières)', compteDate: (n, d) => `${n} titres · ${d}`,
    erreurMot: 'Erreur', erreurGen: (e) => `Erreur : ${e}`,
    erreur403: 'Spotify a refusé l\'accès (403). Vérifie 2 choses dans ton app développeur Spotify : (1) le compte Spotify connecté doit être en Premium, (2) ce compte doit être ajouté dans « User Management » du dashboard (le mode développeur n\'autorise que les comptes listés).',
    aucune: 'Aucune nouvelle découverte trouvée (filtres trop stricts ou historique trop mince). Essayez une autre période, une popularité plus large, ou sans ambiance.',
    ambiances: { '': 'Aucune (juste de la découverte)', bosser: 'Concentration / bosser', relaxation: 'Relaxation profonde (néo-classique, Max Richter…)', chill: 'Chill / détente', matin: 'Matin doux', melancolie: 'Mélancolie', romantique: 'Romantique', jazz: 'Jazz feutré', recevoir: 'Apéro / recevoir', roadtrip: 'Road trip', ete: 'Été / ensoleillé', sport: 'Sport / énergie', soiree: 'Soirée / fête' },
    periodes: { recent: '4 dernières semaines', moyen: '6 derniers mois', tout: 'Tout mon historique' },
    popLabels: ['Confidentiel — uniquement des perles méconnues', 'Underground — peu connu', 'Sous le radar — émergent', 'Assez connu', 'Passe à la radio'],
    histoLabels: ['1 jour', '4 dernières semaines', '6 derniers mois', 'Tout mon historique'],
    popNoteUnderground: 'À ce niveau, certains artistes ont peu d\'infos sur Spotify : les résultats peuvent s\'éloigner un peu des filtres choisis.',
    popNoteConfidentiel: 'Niveau très pointu : faute d\'infos suffisantes sur ces artistes, les filtres ci-dessous sont désactivés pour garantir un résultat cohérent.',
  },
  en: {
    titre: 'OffRadar',
    sousTitre: 'Based on your listening — different artists, more under-the-radar, learning from what you remove.',
    connecte: 'Connected to Spotify', seConnecter: 'Connect to Spotify', deconnexion: 'Log out',
    reglages: 'Edit setup',
    onbTitre: 'Setup (one-time, ~3 min)',
    onbIntro: 'This extension uses your own free Spotify developer account:',
    onbEtape1: 'Open the Spotify Developer Dashboard, then click “Create app”.',
    onbEtape2: 'App name: “OffRadar” (anything) · App description: “personal”.',
    onbEtape3: 'Tick “Web API” in the API types.',
    onbEtape4: 'Under “Redirect URIs”, paste this URL then click “Add”:',
    onbEtape5: 'Click “Save” at the very bottom (often forgotten!).',
    onbUserMgmt: 'In the app’s “User Management” tab, add your Spotify account email (required in development mode).',
    onbEtape6: 'Copy the app’s “Client ID” and paste it below:',
    loginErrChargement: 'Spotify could not open the authorization page. Check that the Redirect URI (see “Edit setup”) is added AND saved (“Save”) in your Spotify app, and that the Client ID is correct.',
    loginErrGenerique: (e) => `Connection failed: ${e}`,
    loginAnnule: 'Sign-in interrupted. If you didn\'t cancel on purpose, check that the Redirect URI is added AND saved (“Save”) in your Spotify app, then try again.',
    onbCopier: 'Copy', onbCopie: 'Copied ✓', onbEnregistrer: 'Save',
    taille: 'Playlist size', segNombre: 'Number of tracks', segDuree: 'Listening time',
    nbMorceaux: 'Number of tracks', dureeCible: 'Target duration',
    uTitres: (n) => `${n} tracks`, uMin: (n) => `${n} min`,
    ambianceLabel: 'Listening mood', notoriete: 'Fame level',
    popDesactive: 'Disabled — fame is not taken into account.',
    styles: 'Music styles',
    stylesAide: 'Click to include or exclude styles. Your usual styles are pre-selected; add others to explore.',
    stylesHisto: 'From your history', stylesPop: 'Popular styles', stylesAutres: 'Other styles',
    aucunStyle: 'No style detected in your listening.', chargement: 'Loading…',
    voirPlus: 'Show more', voirMoins: 'Show less',
    stylesDesactive: 'Disabled — all styles allowed.',
    epoque: 'Era', epoqueAide: 'Pick which decades to include (by release year).',
    epoqueDesactive: 'Disabled — all eras allowed.',
    familiarite: 'Familiarity', famDesactive: 'Disabled — balanced discovery by default.',
    famLabels: ['Very bold — far from my taste', 'Bold', 'Balanced', 'Close to my taste', 'Very close to my taste'],
    explicite: 'Exclude explicit tracks', expliciteAide: 'On: keeps only “clean” tracks (no explicit content).',
    histoRef: 'Reference history', generer: 'Generate a new playlist',
    recherche: 'Finding gems… (~15–30 s)',
    chargementMsgs: ['Analysing your listening…', 'Exploring new artists…', 'Picking the gems…', 'Building your playlist…'],
    ouvrir: 'Open in Spotify', supprimer: 'Delete', partager: 'Share', partageCopie: 'Link copied ✓',
    partageTexte: (nom, url) => `🎧 ${nom}\n${url}\n\nPlaylist made with OffRadar.`,
    partagePromo: 'Playlist made with OffRadar',
    jaquetteErr: (e) => `Cover not set: ${e}`,
    assoupliMsg: 'Your filters were a bit too narrow: I loosened them slightly to fill the playlist.',
    compte: (n, m) => `${n} tracks · ~${m} min`,
    bibliothequeInfo: 'Playlist added to your Spotify library. On the mobile app it may take a moment to appear — reopen the app if needed.',
    renvoyer: 'Send back to Spotify', restauration: 'Restoring…', suppression: 'Deleting…',
    confirmSuppr: 'Delete this playlist from your Spotify? (permanent)',
    histoTitre: 'History (last 10)', compteDate: (n, d) => `${n} tracks · ${d}`,
    erreurMot: 'Error', erreurGen: (e) => `Error: ${e}`,
    erreur403: 'Spotify denied access (403). Check 2 things in your Spotify developer app: (1) the connected Spotify account must be Premium, (2) that account must be added under “User Management” in the dashboard (development mode only allows whitelisted accounts).',
    aucune: 'No new discovery found (filters too strict or listening history too thin). Try another reference period, a wider fame level, or no mood.',
    ambiances: { '': 'None (just discovery)', bosser: 'Focus / work', relaxation: 'Deep relaxation (neoclassical, Max Richter…)', chill: 'Chill', matin: 'Gentle morning', melancolie: 'Melancholy', romantique: 'Romantic', jazz: 'Late-night jazz', recevoir: 'Drinks / hosting', roadtrip: 'Road trip', ete: 'Summer / sunny', sport: 'Sport / energy', soiree: 'Party' },
    periodes: { recent: 'Last 4 weeks', moyen: 'Last 6 months', tout: 'All my history' },
    popLabels: ['Hidden gems only', 'Underground — little known', 'Under the radar — emerging', 'Fairly known', 'Radio hits'],
    histoLabels: ['1 day', 'Last 4 weeks', 'Last 6 months', 'All my history'],
    popNoteUnderground: 'At this level, some artists have little info on Spotify: results may stray a bit from the chosen filters.',
    popNoteConfidentiel: 'Very niche level: with too little info on these artists, the filters below are disabled to guarantee a coherent result.',
  },
};

// =====================================================================
//  État + helpers
// =====================================================================
let lang = 'fr';
let mesure = 'nombre';
let genresData = null;
let autresAffiches = 20;
let dernierResultat = null;
const selection = new Set();
const selectionEpoque = new Set(); // décennies incluses (valeurs de DECENNIES)

const t = (key, ...args) => { const v = I18N[lang][key]; return typeof v === 'function' ? v(...args) : v; };
const $ = (id) => document.getElementById(id);
const montrer = (id) => $(id).classList.remove('cache');
const cacher = (id) => $(id).classList.add('cache');
const delai = (ms) => new Promise((r) => setTimeout(r, ms));
const escapeHtml = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
const normaliser = (s) => (s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\(.*?\)|\[.*?\]/g, '').replace(/[^a-z0-9]/g, '').trim();
// Retire les suffixes de version (« - Live », « - 2011 Remaster », « - Radio Edit »…)
// pour que les variantes d'un même titre soient dédoublonnées.
const nettoyerTitre = (t) => (t || '').replace(/\s[-–]\s.*(live|remix|remaster|acoustic|version|edit|mix|mono|stereo|deluxe|bonus|radio|demo|instrumental|edition|session).*/i, '');
const cleMorceau = (a, t2) => `${normaliser(a)}::${normaliser(nettoyerTitre(t2))}`;
const capitaliser = (s) => s.replace(/\b\w/g, (c) => c.toUpperCase());

const store = {
  get: (k) => new Promise((r) => chrome.storage.local.get(k, (o) => r(o[k]))),
  set: (k, v) => new Promise((r) => chrome.storage.local.set({ [k]: v }, r)),
  remove: (k) => new Promise((r) => chrome.storage.local.remove(k, r)),
};

async function pMap(items, fn, concurrence = 5) {
  const out = new Array(items.length);
  let i = 0;
  const worker = async () => { while (i < items.length) { const idx = i++; out[idx] = await fn(items[idx], idx); } };
  await Promise.all(Array.from({ length: Math.min(concurrence, items.length) }, worker));
  return out;
}

// =====================================================================
//  Jetons + OAuth PKCE
// =====================================================================
const lireTokens = () => store.get('tokens');
const ecrireTokens = (tk) => store.set('tokens', tk);

const b64url = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const sha256 = (str) => crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));

async function getAccessToken() {
  let tk = await lireTokens();
  if (!tk) throw new Error('NON_CONNECTE');
  if (Date.now() < tk.expires_at - 60000) return tk.access_token;
  const clientId = await store.get('clientId');
  const res = await fetch('https://accounts.spotify.com/api/token', {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'refresh_token', refresh_token: tk.refresh_token, client_id: clientId }),
  });
  if (!res.ok) throw new Error('NON_CONNECTE');
  const data = await res.json();
  tk = { access_token: data.access_token, refresh_token: data.refresh_token || tk.refresh_token, expires_at: Date.now() + data.expires_in * 1000, user_id: tk.user_id, scope: data.scope || tk.scope };
  await ecrireTokens(tk);
  return tk.access_token;
}

async function login() {
  const clientId = await store.get('clientId');
  if (!clientId) { await rafraichirVue(); return; }
  $('login-erreur').classList.add('cache');
  let etape = 'init';
  try {
    const redirectUri = api.identity.getRedirectURL();
    const verifier = b64url(crypto.getRandomValues(new Uint8Array(48)));
    const challenge = b64url(await sha256(verifier));
    const params = new URLSearchParams({ response_type: 'code', client_id: clientId, scope: SCOPES, redirect_uri: redirectUri, code_challenge_method: 'S256', code_challenge: challenge, show_dialog: 'true' });

    etape = 'launchWebAuthFlow';
    let redirect;
    try {
      redirect = await api.identity.launchWebAuthFlow({ url: `https://accounts.spotify.com/authorize?${params}`, interactive: true });
    } catch (e) {
      const m = (e && e.message) || String(e);
      // Fenêtre fermée / annulée (volontairement OU après une erreur Spotify type
      // redirect_uri non enregistré). On affiche un message clair plutôt que rien.
      if (/did not approve|cancel|closed|denied|interaction/i.test(m)) {
        const el = $('login-erreur');
        el.textContent = t('loginAnnule');
        el.classList.remove('cache');
        return;
      }
      throw new Error('launchWebAuthFlow: ' + m);
    }

    etape = 'lecture du retour';
    const u = new URL(redirect);
    const errSpotify = u.searchParams.get('error');
    if (errSpotify) throw new Error('Spotify a refusé : ' + errSpotify);
    const code = u.searchParams.get('code');
    if (!code) throw new Error('Aucun code dans le retour : ' + redirect);

    etape = 'échange du jeton';
    const res = await fetch('https://accounts.spotify.com/api/token', {
      method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ grant_type: 'authorization_code', code, redirect_uri: redirectUri, client_id: clientId, code_verifier: verifier }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error('jeton refusé (' + res.status + ') : ' + (data.error_description || data.error || JSON.stringify(data)));

    etape = 'profil /me';
    let userId = null;
    try { const me = await fetch('https://api.spotify.com/v1/me', { headers: { Authorization: `Bearer ${data.access_token}` } }); if (me.ok) userId = (await me.json()).id; } catch {}

    etape = 'enregistrement';
    console.log('[Spotify] scopes accordés :', data.scope || '(aucun renvoyé)');
    await ecrireTokens({ access_token: data.access_token, refresh_token: data.refresh_token, expires_at: Date.now() + data.expires_in * 1000, user_id: userId, scope: data.scope || '' });
    genresData = null; selection.clear();
    await rafraichirVue();
  } catch (e) {
    console.error('[login]', etape, e);
    const m = (e && e.message) || String(e);
    const txt = (etape === 'launchWebAuthFlow' || /could not be loaded|authorization page/i.test(m))
      ? t('loginErrChargement')
      : t('loginErrGenerique', m);
    const el = $('login-erreur');
    el.textContent = txt;
    el.classList.remove('cache');
  }
}

async function deconnexion() {
  await store.remove('tokens');
  dernierResultat = null; genresData = null; selection.clear();
  $('carte-resultat').innerHTML = ''; cacher('carte-resultat');
  $('zone-historique').innerHTML = '';
  $('styles-actif').checked = false;
  await rafraichirVue();
}

// =====================================================================
//  API Spotify / Last.fm
// =====================================================================
async function spotify(endpoint, options = {}, tentative = 0) {
  const token = await getAccessToken();
  const res = await fetch(`https://api.spotify.com/v1${endpoint}`, {
    ...options, headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', ...(options.headers || {}) },
  });
  if (res.status === 429 && tentative < 4) {
    const a = Math.min(parseInt(res.headers.get('retry-after') || '1', 10), 8);
    await delai(a * 1000 + 300);
    return spotify(endpoint, options, tentative + 1);
  }
  if (res.status === 204 || res.status === 202) return null;
  const txt = await res.text();
  const data = txt ? JSON.parse(txt) : null;
  if (!res.ok) throw new Error(`Spotify ${res.status} (${endpoint}): ${txt}`);
  return data;
}

async function lastfm(method, params) {
  const url = new URL('https://ws.audioscrobbler.com/2.0/');
  url.searchParams.set('method', method);
  url.searchParams.set('api_key', LASTFM_API_KEY);
  url.searchParams.set('format', 'json');
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
  const res = await fetch(url);
  const data = await res.json();
  if (data.error) throw new Error(`Last.fm ${data.error}`);
  return data;
}

// =====================================================================
//  Historique (chrome.storage, isolé par compte Spotify)
// =====================================================================
async function histoKey() { const tk = await lireTokens(); return `histo_${tk?.user_id || 'default'}`; }
async function lireHisto() { const h = await store.get(await histoKey()); return { blacklist: [], playlists: [], ...(h || {}) }; }
async function ecrireHisto(h) { await store.set(await histoKey(), h); }

async function apprendreDesSuppressions(histo) {
  await pMap(histo.playlists, async (pl) => {
    let presentes;
    try {
      const data = await spotify(`/playlists/${pl.id}/tracks?fields=items(track(uri))&limit=100`);
      presentes = new Set((data.items || []).map((i) => i.track?.uri).filter(Boolean));
    } catch { return; }
    for (const m of pl.morceaux) if (!presentes.has(m.uri) && !histo.blacklist.includes(m.cle)) histo.blacklist.push(m.cle);
  }, 3);
}

// =====================================================================
//  Jaquette (Canvas)
// =====================================================================
function couleursDepuisSeed(seed) {
  const h1 = (seed * 47) % 360, h2 = (h1 + 35 + (seed % 70)) % 360, r = ((seed % 360) * Math.PI) / 180;
  return { c1: `hsl(${h1},68%,47%)`, c2: `hsl(${h2},62%,30%)`, x1: 0.5 - 0.5 * Math.cos(r), y1: 0.5 - 0.5 * Math.sin(r), x2: 0.5 + 0.5 * Math.cos(r), y2: 0.5 + 0.5 * Math.sin(r) };
}
function dessinerJaquette(titre, seed, label) {
  const c = document.createElement('canvas'); c.width = 640; c.height = 640;
  const x = c.getContext('2d');
  const { c1, c2, x1, y1, x2, y2 } = couleursDepuisSeed(seed);
  const g = x.createLinearGradient(x1 * 640, y1 * 640, x2 * 640, y2 * 640);
  g.addColorStop(0, c1); g.addColorStop(1, c2);
  x.fillStyle = g; x.fillRect(0, 0, 640, 640);
  x.fillStyle = 'rgba(255,255,255,0.10)';
  x.beginPath(); x.arc(490, 150, 200, 0, 7); x.fill();
  x.beginPath(); x.arc(120, 520, 150, 0, 7); x.fill();
  x.strokeStyle = 'rgba(255,255,255,0.18)'; x.lineWidth = 3;
  for (const rr of [120, 170, 220]) { x.beginPath(); x.arc(320, 320, rr, 0, 7); x.stroke(); }
  x.fillStyle = '#fff'; x.textAlign = 'center';
  x.font = '700 58px Helvetica, Arial, sans-serif'; x.fillText(titre, 320, 312);
  x.globalAlpha = 0.85; x.font = '26px Helvetica, Arial, sans-serif';
  try { x.letterSpacing = '4px'; } catch {}
  x.fillText(label, 320, 360);
  try { x.letterSpacing = '0px'; } catch {}
  x.globalAlpha = 0.7; x.font = '22px Helvetica, Arial, sans-serif';
  x.fillText(new Date().toLocaleDateString(lang === 'en' ? 'en-GB' : 'fr-FR'), 320, 596);
  x.globalAlpha = 1;
  return c;
}
const jaquetteDataUrl = (titre, seed, label) => dessinerJaquette(titre, seed, label).toDataURL('image/jpeg', 0.82);
const jaquetteBase64 = (titre, seed, label) => jaquetteDataUrl(titre, seed, label).split(',')[1];

// =====================================================================
//  Sélection des morceaux (cœur de l'algo)
// =====================================================================
async function selectionnerMorceaux({ histoStep, ambianceCle, popMin = 0, popMax, mesure: mes, nbVoulu, cibleMs, genresSel, genresExcl, epoques, excludeExplicit, biais }, histo) {
  const amb = AMBIANCES[ambianceCle];
  let topArtists, topTracks;
  const recents = await spotify('/me/player/recently-played?limit=50');
  if (histoStep.range) {
    // Horizons longs : on utilise le vrai « top » Spotify
    [topArtists, topTracks] = await Promise.all([
      spotify(`/me/top/artists?limit=30&time_range=${histoStep.range}`),
      spotify(`/me/top/tracks?limit=50&time_range=${histoStep.range}`),
    ]);
  } else {
    // Horizon court (en jours) : on dérive le goût de l'écoute récente datée
    const cutoff = Date.now() - histoStep.jours * 86400000;
    const recentsFiltres = (recents.items || []).filter((i) => Date.parse(i.played_at) >= cutoff);
    const freq = new Map();
    const pistes = [];
    for (const i of recentsFiltres) { const tr = i.track; if (!tr) continue; pistes.push(tr); const a = tr.artists[0]; if (a) freq.set(a.name, (freq.get(a.name) || 0) + 1); }
    topArtists = { items: [...freq.entries()].sort((a, b) => b[1] - a[1]).map(([name]) => ({ name })) };
    topTracks = { items: pistes };
  }
  const artistesConnus = new Set();
  for (const a of topArtists.items) artistesConnus.add(normaliser(a.name));
  for (const tr of topTracks.items) for (const a of tr.artists) artistesConnus.add(normaliser(a.name));
  const exclus = new Set(histo.blacklist);
  for (const tr of topTracks.items) exclus.add(cleMorceau(tr.artists[0].name, tr.name));
  for (const r of recents.items) exclus.add(cleMorceau(r.track.artists[0].name, r.track.name));
  // Anti-répétition bornée : morceaux déjà présents dans les 10 dernières playlists
  // (soft : autorisés en tout dernier recours si le vivier est insuffisant)
  const recentsSet = new Set();
  for (const pl of histo.playlists) for (const m of pl.morceaux) if (m.cle) recentsSet.add(m.cle);

  const scores = new Map();
  const ajouterCandidat = (nom, sc) => { if (!artistesConnus.has(normaliser(nom))) scores.set(nom, (scores.get(nom) || 0) + sc); };

  if (genresSel && genresSel.size) {
    // STYLE CHOISI → les filtres priment sur l'historique : le vivier vient du
    // style (et non des artistes habituels, qui ramèneraient le goût personnel).
    const tg = await pMap([...genresSel].slice(0, 5), (tag) => lastfm('tag.getTopArtists', { tag, limit: 80 }).catch(() => null));
    const artistesGenre = [];
    for (const tr of tg) for (const a of tr?.topartists?.artist || []) { ajouterCandidat(a.name, 1); artistesGenre.push(a.name); }
    // Découverte DANS le style : artistes similaires aux artistes du genre
    const sims = await pMap(artistesGenre.slice(0, 25), (nom) => lastfm('artist.getSimilar', { artist: nom, limit: 20 }).catch(() => null));
    for (const sim of sims) for (const a of sim?.similarartists?.artist || []) ajouterCandidat(a.name, 0.5);
  } else {
    // Pas de filtre de style : découverte à partir de l'historique (+ ambiance éventuelle)
    // 1) Artistes "dans le mood" (tags de l'ambiance) → affinité légère + set de référence
    const moodSet = new Set();
    if (amb.tags.length) {
      const tg = await pMap(amb.tags.slice(0, 4), (tag) => lastfm('tag.getTopArtists', { tag, limit: 60 }).catch(() => null));
      for (const tr of tg) for (const a of tr?.topartists?.artist || []) { ajouterCandidat(a.name, 0.7); moodSet.add(normaliser(a.name)); }
    }
    // 2) Similaires à ton historique (score = proximité). BONUS de chevauchement :
    //    un artiste à la fois proche de ton goût ET dans le mood = idéal → forte priorité.
    const bonusDonne = new Set();
    const graines = topArtists.items.slice(0, 25).map((a) => a.name);
    const sims = await pMap(graines, (nom) => lastfm('artist.getSimilar', { artist: nom, limit: 30 }).catch(() => null));
    for (const sim of sims) for (const a of sim?.similarartists?.artist || []) {
      ajouterCandidat(a.name, parseFloat(a.match) || 0.1);
      const na = normaliser(a.name);
      if (moodSet.has(na) && !bonusDonne.has(na)) { ajouterCandidat(a.name, 1.5); bonusDonne.add(na); }
    }
  }
  // Ordre = tirage aléatoire PONDÉRÉ par le score (Efraimidis-Spirakis) : les
  // bons matchs restent favorisés, mais l'ordre varie à chaque génération.
  // Le biais de familiarité accentue (proche des goûts) ou aplatit (audacieux)
  // l'influence du score de proximité dans le tirage aléatoire pondéré.
  // Classement = tirage aléatoire PONDÉRÉ par le score (Efraimidis-Spirakis) :
  // les bons matchs restent favorisés, l'ordre varie à chaque génération.
  // Le biais de familiarité accentue (proche) ou aplatit (audacieux) l'influence du score.
  const b = biais || 1;
  const classed = [...scores.entries()]
    .map(([nom, sc]) => [nom, Math.pow(Math.random(), 1 / (sc * b + 0.05))])
    .sort((a, b2) => b2[1] - a[1])
    .map(([nom]) => nom);

  const estJunk = (p) => /karaoke|tribute|made famous|originally performed|cover version|8-bit|8 bit|piano version of/i.test(p.artists.map((a) => a.name).join(' ') + ' ' + p.name);
  const estVersion = (p) => /\b(live|remix|remaster|acoustic|edit|mono|demo|instrumental|sped up|slowed)\b/i.test(p.name);
  const rechercher = async ({ artiste, titre }) => {
    const q = encodeURIComponent(`track:${titre} artist:${artiste}`);
    let items;
    try { const r = await spotify(`/search?q=${q}&type=track&limit=5`); items = r.tracks?.items || []; }
    catch { return null; }
    if (!items.length) return null;
    const na = normaliser(artiste), nt = normaliser(titre);
    // On exige que le morceau soit bien DE l'artiste candidat (évite les mauvais
    // rattachements), on écarte karaoké/reprises, et on privilégie la version studio
    // (sans live/remix) puis le titre exact.
    const bons = items.filter((p) => !estJunk(p) && p.artists.some((a) => normaliser(a.name) === na));
    const p =
      bons.find((x) => normaliser(x.name) === nt && !estVersion(x)) ||
      bons.find((x) => !estVersion(x)) ||
      bons.find((x) => normaliser(x.name) === nt) ||
      bons[0] ||
      items.filter((x) => !estJunk(x))[0];
    if (!p) return null;
    return {
      artiste: p.artists[0]?.name || artiste, artisteId: p.artists[0]?.id || null,
      titre: p.name, uri: p.uri, popularite: p.popularity, dureeMs: p.duration_ms || 0,
      annee: parseInt((p.album?.release_date || '').slice(0, 4)) || null,
      explicit: !!p.explicit,
    };
  };

  const analyserLot = async (lot) => {
    const ids = [...new Set(lot.filter((p) => p?.artisteId).map((p) => p.artisteId))];
    const parId = new Map();
    if (ids.length) { try { const data = await spotify(`/artists?ids=${ids.join(',')}`); for (const a of data.artists || []) parId.set(a.id, { genres: a.genres || [], pop: a.popularity }); } catch {} }
    return (p) => {
      const info = parId.get(p.artisteId);
      const gs = info?.genres;
      const pop = info && info.pop != null ? info.pop : p.popularite;
      let okGenre = true;
      if (genresSel && genresSel.size) {
        // Style choisi : le vivier est déjà sourcé depuis la balise Last.fm du style.
        // Les genres Spotify sont trop incohérents (j-pop / j-rock / anime / city pop…)
        // pour re-filtrer fiablement → on fait confiance au sourcing.
        okGenre = true;
      } else if (gs && gs.length && amb.exclure.length) {
        // Mode ambiance : on exclut seulement les genres incompatibles avec le mood
        if (gs.some((g) => amb.exclure.some((e) => g.includes(e)))) okGenre = false;
      }
      return { okGenre, pop };
    };
  };

  const retenus = []; const artistesUtilises = new Set(); const clesUtilisees = new Set();
  const recalesPop = []; const recalesRepet = [];
  let dureeMs = 0, assoupli = false;
  const assez = () => (mes === 'duree' ? dureeMs >= cibleMs || retenus.length >= 80 : retenus.length >= nbVoulu);
  const ajouter = (p) => { artistesUtilises.add(normaliser(p.artiste)); clesUtilisees.add(cleMorceau(p.artiste, p.titre)); dureeMs += p.dureeMs; retenus.push({ artiste: p.artiste, titre: p.titre, uri: p.uri, explicit: p.explicit }); };

  // Traite une tranche d'artistes : récupère leurs titres, vérifie sur Spotify,
  // applique les filtres et remplit la playlist jusqu'à la cible.
  const traiter = async (liste) => {
    const tops = await pMap(liste, (artiste) =>
      lastfm('artist.getTopTracks', { artist: artiste, limit: 3 })
        .then((r) => ({ artiste, titres: (r.toptracks?.track || []).map((x) => x.name) }))
        .catch(() => ({ artiste, titres: [] })), 5);
    const file = [];
    for (const { artiste, titres } of tops) {
      if (artistesUtilises.has(normaliser(artiste))) continue;
      const ti = titres.find((x) => !exclus.has(cleMorceau(artiste, x)));
      if (ti) file.push({ artiste, titre: ti });
    }
    for (let i = 0; i < file.length && !assez(); i += 5) {
      const lot = await pMap(file.slice(i, i + 5), rechercher, 5);
      const infos = await analyserLot(lot);
      for (const p of lot) {
        if (assez()) break;
        if (!p) continue;
        const na = normaliser(p.artiste), cle = cleMorceau(p.artiste, p.titre);
        if (artistesConnus.has(na) || artistesUtilises.has(na)) continue;
        if (exclus.has(cle) || clesUtilisees.has(cle)) continue;
        const { okGenre, pop } = infos(p);
        if (!okGenre) continue;
        if (epoques && !epoques.has(decennieDe(p.annee))) continue; // hors décennies choisies
        if (excludeExplicit && p.explicit) continue; // contenu explicite exclu
        p.pop = pop;
        if (recentsSet.has(cle)) { recalesRepet.push(p); continue; } // déjà dans une playlist récente
        if (pop < popMin || pop > popMax) { recalesPop.push(p); continue; } // hors de la bande de notoriété
        ajouter(p);
      }
    }
  };

  // Élargissement À LA DEMANDE : on ne traite (et ne va chercher les titres de)
  // chaque palier que si le précédent n'a pas suffi → générations normales rapides,
  // grosses playlists / générations rapprochées puisent plus profond sans ralentir tout le monde.
  let debut = 0;
  for (const fin of [150, 350, 600]) {
    if (assez()) break;
    const tranche = classed.slice(debut, fin);
    if (!tranche.length) break;
    await traiter(tranche);
    debut = fin;
  }

  const MARGE_POP = 18;
  // Écart d'un artiste par rapport à la bande [popMin, popMax] (0 = dans la bande)
  const ecartBande = (p) => (p.pop < popMin ? popMin - p.pop : p.pop > popMax ? p.pop - popMax : 0);
  // 1er recours : on élargit la bande (des deux côtés), en privilégiant les plus proches.
  if (!assez() && recalesPop.length) {
    recalesPop.sort((a, b) => ecartBande(a) - ecartBande(b));
    for (const p of recalesPop) {
      if (assez()) break;
      if (ecartBande(p) > MARGE_POP) break;
      const na = normaliser(p.artiste), cle = cleMorceau(p.artiste, p.titre);
      if (artistesUtilises.has(na) || clesUtilisees.has(cle)) continue;
      ajouter(p); assoupli = true;
    }
  }
  // 2e recours : si toujours insuffisant, on réautorise des titres déjà proposés
  // récemment (en respectant la bande de notoriété choisie). Évite tout échec.
  if (!assez() && recalesRepet.length) {
    recalesRepet.sort((a, b) => a.pop - b.pop);
    for (const p of recalesRepet) {
      if (assez()) break;
      if (p.pop < popMin || p.pop > popMax) continue;
      const na = normaliser(p.artiste), cle = cleMorceau(p.artiste, p.titre);
      if (artistesUtilises.has(na) || clesUtilisees.has(cle)) continue;
      ajouter(p); assoupli = true;
    }
  }
  return { retenus, dureeMs, assoupli };
}

// =====================================================================
//  Styles (chips)
// =====================================================================
async function chargerGenresData() {
  const [top, chart] = await Promise.all([
    spotify('/me/top/artists?limit=50&time_range=long_term').catch(() => ({ items: [] })),
    lastfm('chart.getTopTags', { limit: 200 }).catch(() => ({ tags: { tag: [] } })),
  ]);
  const compte = new Map();
  for (const a of top.items || []) for (const g of a.genres || []) compte.set(g, (compte.get(g) || 0) + 1);
  const historique = [...compte.entries()].sort((a, b) => b[1] - a[1]).slice(0, 14).map(([g]) => g);
  const vus = new Set(historique.map((g) => g.toLowerCase()));
  const mondiaux = [];
  for (const tg of chart.tags?.tag || []) {
    const nom = tg.name;
    if (!estGenre(nom) || vus.has(nom.toLowerCase())) continue;
    vus.add(nom.toLowerCase()); mondiaux.push(nom);
    if (mondiaux.length >= 80) break;
  }
  return { historique, populaires: mondiaux.slice(0, 20), autres: mondiaux.slice(20) };
}

function chipHTML(g) { return `<span class="chip${selection.has(g.toLowerCase()) ? ' selectionne' : ''}" data-genre="${escapeHtml(g)}">${escapeHtml(g)}</span>`; }
function renderAutres() {
  $('chips-autres').innerHTML = genresData.autres.slice(0, autresAffiches).map(chipHTML).join('');
  const btn = $('btn-voir-plus');
  if (genresData.autres.length <= 20) { btn.classList.add('cache'); }
  else { btn.classList.remove('cache'); btn.textContent = autresAffiches < genresData.autres.length ? t('voirPlus') : t('voirMoins'); }
}
async function chargerGenres() {
  try { genresData = await chargerGenresData(); } catch { genresData = { historique: [], populaires: [], autres: [] }; }
  selection.clear();
  for (const g of genresData.historique) selection.add(g.toLowerCase());
  $('chips-historique').innerHTML = genresData.historique.length ? genresData.historique.map(chipHTML).join('') : `<span class="aide">${t('aucunStyle')}</span>`;
  $('chips-populaires').innerHTML = genresData.populaires.map(chipHTML).join('');
  renderAutres();
}

// =====================================================================
//  Génération + rendu
// =====================================================================
async function generer() {
  const btn = $('btn-generer');
  const carte = $('carte-resultat');
  btn.disabled = true; montrer('carte-resultat');
  const msgs = I18N[lang].chargementMsgs;
  carte.innerHTML = `<div class="chargement">
    <svg class="vinyle-spin" viewBox="0 0 256 256" fill="currentColor"><path d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24ZM72,128a8,8,0,0,1-16,0,72.08,72.08,0,0,1,72-72,8,8,0,0,1,0,16A56.06,56.06,0,0,0,72,128Zm32,0a24,24,0,1,1,24,24A24,24,0,0,1,104,128Zm24,72a8,8,0,0,1,0-16,56.06,56.06,0,0,0,56-56,8,8,0,0,1,16,0A72.08,72.08,0,0,1,128,200Z"/></svg>
    <div class="chargement-msg" id="chargement-msg">${msgs[0]}</div></div>`;
  carte.scrollIntoView({ behavior: 'smooth', block: 'start' });
  let mi = 0;
  const interval = setInterval(() => { mi = (mi + 1) % msgs.length; const el = $('chargement-msg'); if (el) el.textContent = msgs[mi]; }, 2300);
  try {
    const popActif = $('pop-actif').checked;
    const niveauPop = +$('curseur-pop').value;
    // Notoriété en BANDES : chaque niveau = une plage [min, max] de popularité d'artiste.
    const popMin = popActif ? (POP_SEUILS[niveauPop - 2] || 0) : 0;
    const popMax = popActif ? POP_SEUILS[niveauPop - 1] : 100;
    const confidentiel = popActif && niveauPop === 1; // en confidentiel, on ignore les filtres « en dessous »
    const stylesActif = $('styles-actif').checked && !confidentiel;
    const ambianceCle = confidentiel ? '' : (AMBIANCES[$('ambiance').value] ? $('ambiance').value : '');
    const histoStep = HISTO_STEPS[+$('curseur-histo').value - 1] || HISTO_STEPS[3];
    const genresSel = stylesActif && selection.size ? new Set([...selection]) : null;
    const genresExcl = stylesActif && genresData ? new Set(genresData.historique.map((g) => g.toLowerCase()).filter((g) => !selection.has(g))) : null;
    const epoques = !confidentiel && $('epoque-actif').checked && selectionEpoque.size ? new Set([...selectionEpoque]) : null;
    const excludeExplicit = !confidentiel && $('explicite-actif').checked;
    const biais = $('fam-actif').checked ? FAM_BIAIS[+$('curseur-fam').value - 1] : 1;
    const nbVoulu = Math.min(Math.max(+$('curseur-nb').value || 25, 5), 50);
    const cibleMs = Math.min(Math.max(+$('curseur-duree').value || 30, 5), 180) * 60000;

    const histo = await lireHisto();
    await apprendreDesSuppressions(histo);
    const { retenus, dureeMs, assoupli } = await selectionnerMorceaux({ histoStep, ambianceCle, popMin, popMax, mesure, nbVoulu, cibleMs, genresSel, genresExcl, epoques, excludeExplicit, biais }, histo);

    if (!retenus.length) { carte.innerHTML = `<div class="erreur">${t('aucune')}</div>`; return; }

    const uris = retenus.map((r) => r.uri);
    const moi = await spotify('/me');
    // Titre (nom de playlist + jaquette) : ambiance si choisie, sinon style sélectionné, sinon « Découvertes »
    let titre = titreAmb(ambianceCle, lang);
    if (!ambianceCle && stylesActif && selection.size) titre = capitaliser([...selection][0]);
    const date = new Date().toLocaleDateString(lang === 'en' ? 'en-GB' : 'fr-FR');
    const nom = `${PREFIXE_NOM[lang]} · ${titre} · ${date}`;
    const motT = lang === 'en' ? 'tracks' : 'titres';
    const seed = Date.now() % 1000000;
    const pl = await spotify(`/users/${moi.id}/playlists`, { method: 'POST', body: JSON.stringify({ name: nom, description: `${titre} · ${date} · ${uris.length} ${motT}`, public: false }) });
    await spotify(`/playlists/${pl.id}/tracks`, { method: 'POST', body: JSON.stringify({ uris }) });
    let jaquetteErreur = null;
    try { await spotify(`/playlists/${pl.id}/images`, { method: 'PUT', headers: { 'Content-Type': 'image/jpeg' }, body: jaquetteBase64(titre, seed, LABEL_JAQUETTE[lang]) }); }
    catch (e) { jaquetteErreur = /401|403/.test(e.message) ? (lang === 'en' ? 'missing permission' : 'permission manquante') : e.message; }

    histo.playlists.unshift({ id: pl.id, nom, ambiance: ambianceCle, titre, seed, lang, date, morceaux: retenus.map((r) => ({ artiste: r.artiste, titre: r.titre, uri: r.uri, explicit: r.explicit, cle: cleMorceau(r.artiste, r.titre) })) });
    histo.playlists = histo.playlists.slice(0, MAX_HISTO);
    await ecrireHisto(histo);

    dernierResultat = { id: pl.id, nom, ambiance: ambianceCle, titre, seed, lang, url: pl.external_urls.spotify, dureeMin: Math.round(dureeMs / 60000), assoupli, jaquetteErreur, morceaux: retenus.map(({ artiste, titre: ti, explicit }) => ({ artiste, titre: ti, explicit })) };
    afficherResultat(dernierResultat);
    carte.scrollIntoView({ behavior: 'smooth', block: 'start' });
    await chargerHistorique();
  } catch (e) {
    if (e.message === 'NON_CONNECTE') { await rafraichirVue(); return; }
    const msg = /Spotify 403/.test(e.message) ? t('erreur403') : t('erreurGen', e.message);
    carte.innerHTML = `<div class="erreur">${msg}</div>`;
  } finally { clearInterval(interval); btn.disabled = false; }
}

function afficherResultat(r) {
  montrer('carte-resultat');
  const img = jaquetteDataUrl(r.titre || titreAmb(r.ambiance, r.lang || lang), r.seed, LABEL_JAQUETTE[r.lang || lang]);
  const liste = r.morceaux.map((m) => `<li>${m.explicit ? '<span class="badge-explicit">E</span> ' : ''}${escapeHtml(m.titre)} <span class="artiste">— ${escapeHtml(m.artiste)}</span></li>`).join('');
  const avert = r.jaquetteErreur ? `<div class="avert">${ICON.warn} ${t('jaquetteErr', r.jaquetteErreur)}</div>` : '';
  const info = r.assoupli ? `<div class="avert">${ICON.warn} ${t('assoupliMsg')}</div>` : '';
  $('carte-resultat').innerHTML = `
    <div class="resultat-haut">
      <img src="${img}" alt="" />
      <div><h3>${escapeHtml(r.nom)}</h3><div class="aide">${t('compte', r.morceaux.length, r.dureeMin)}</div></div>
    </div>
    <div class="ligne-btn">
      <a class="btn btn-primary" href="${r.url}" target="_blank">${ICON.spotify} ${t('ouvrir')}</a>
      <button class="btn btn-ghost" data-action="partager" data-id="${r.id}" data-nom="${escapeHtml(r.nom)}">${ICON.share} ${t('partager')}</button>
      <button class="btn btn-danger" data-action="suppr-res" data-id="${r.id}">${ICON.trash} ${t('supprimer')}</button>
    </div>
    <div class="aide" style="margin-top:8px">${t('bibliothequeInfo')}</div>
    ${info}${avert}
    <ol class="titres">${liste}</ol>`;
}

async function chargerHistorique() {
  const zone = $('zone-historique');
  const histo = await lireHisto();
  const liste = histo.playlists || [];
  if (!liste.length) { zone.innerHTML = ''; return; }
  zone.innerHTML = `<div class="titre-section">${t('histoTitre')}</div>` + liste.map((p, idx) => {
    const img = jaquetteDataUrl(p.titre || titreAmb(p.ambiance, p.lang || 'fr'), p.seed, LABEL_JAQUETTE[p.lang || 'fr']);
    const titres = p.morceaux.map((m) => `<li>${m.explicit ? '<span class="badge-explicit">E</span> ' : ''}${escapeHtml(m.titre)} <span class="artiste">— ${escapeHtml(m.artiste)}</span></li>`).join('');
    return `
      <div class="accordeon-item" id="histo-${idx}">
        <button class="accordeon-tete" data-action="toggle" data-idx="${idx}">
          <img src="${img}" alt="" />
          <div class="meta"><div class="nom">${escapeHtml(p.nom)}</div><div class="compte">${t('compteDate', p.morceaux.length, p.date)}</div></div>
          ${ICON.caret}
        </button>
        <div class="accordeon-corps">
          <div class="ligne-btn">
            <button class="btn btn-ghost" data-action="restaurer" data-id="${p.id}">${ICON.restore} ${t('renvoyer')}</button>
            <button class="btn btn-ghost" data-action="partager" data-id="${p.id}" data-nom="${escapeHtml(p.nom)}">${ICON.share} ${t('partager')}</button>
            <button class="btn btn-danger" data-action="suppr" data-id="${p.id}">${ICON.trash} ${t('supprimer')}</button>
          </div>
          <ol>${titres}</ol>
        </div>
      </div>`;
  }).join('');
}

async function restaurer(id, bouton) {
  bouton.disabled = true; bouton.innerHTML = `${ICON.spinner} ${t('restauration')}`;
  try {
    try {
      await spotify(`/playlists/${id}/followers`, { method: 'PUT', body: JSON.stringify({ public: false }) });
      let url = `https://open.spotify.com/playlist/${id}`;
      try { const d = await spotify(`/playlists/${id}?fields=external_urls`); url = d.external_urls.spotify; } catch {}
      bouton.outerHTML = `<a class="btn btn-primary" href="${url}" target="_blank">${ICON.spotify} ${t('ouvrir')}</a>`;
    } catch {
      const histo = await lireHisto();
      const pl = histo.playlists.find((p) => p.id === id);
      const moi = await spotify('/me');
      const nv = await spotify(`/users/${moi.id}/playlists`, { method: 'POST', body: JSON.stringify({ name: pl.nom, description: 'Restaurée', public: false }) });
      const uris = pl.morceaux.map((m) => m.uri);
      for (let i = 0; i < uris.length; i += 100) await spotify(`/playlists/${nv.id}/tracks`, { method: 'POST', body: JSON.stringify({ uris: uris.slice(i, i + 100) }) });
      const lg = pl.lang || 'fr';
      try { await spotify(`/playlists/${nv.id}/images`, { method: 'PUT', headers: { 'Content-Type': 'image/jpeg' }, body: jaquetteBase64(titreAmb(pl.ambiance, lg), pl.seed || 1, LABEL_JAQUETTE[lg]) }); } catch {}
      pl.id = nv.id; await ecrireHisto(histo);
      bouton.outerHTML = `<a class="btn btn-primary" href="${nv.external_urls.spotify}" target="_blank">${ICON.spotify} ${t('ouvrir')}</a>`;
    }
  } catch (e) { bouton.disabled = false; bouton.innerHTML = `${ICON.warn} ${t('erreurMot')}`; }
}

async function partager(id, nom, bouton) {
  // On partage la page d'accueil brandée si elle est configurée, sinon le lien Spotify brut.
  const url = PAGE_PARTAGE
    ? `${PAGE_PARTAGE.replace(/\/$/, '')}/?p=${id}`
    : `https://open.spotify.com/playlist/${id}`;
  // Rendre la playlist publique pour que le lien soit ouvrable/enregistrable par le receveur
  try { await spotify(`/playlists/${id}`, { method: 'PUT', body: JSON.stringify({ public: true }) }); } catch {}
  if (navigator.share) {
    try { await navigator.share({ title: nom, text: t('partagePromo'), url }); } catch {}
    return;
  }
  // Repli : on copie le lien (+ promo légère) dans le presse-papier
  try {
    await navigator.clipboard.writeText(t('partageTexte', nom, url));
    const ancien = bouton.innerHTML;
    bouton.innerHTML = `${ICON.check} ${t('partageCopie')}`;
    setTimeout(() => { bouton.innerHTML = ancien; }, 2000);
  } catch {}
}

async function supprimer(id, bouton, estResultat) {
  if (!confirm(t('confirmSuppr'))) return;
  bouton.disabled = true; bouton.innerHTML = `${ICON.spinner} ${t('suppression')}`;
  try {
    try { await spotify(`/playlists/${id}/followers`, { method: 'DELETE' }); } catch {}
    const histo = await lireHisto();
    histo.playlists = histo.playlists.filter((p) => p.id !== id);
    await ecrireHisto(histo);
    if (estResultat) { dernierResultat = null; $('carte-resultat').innerHTML = ''; cacher('carte-resultat'); }
    await chargerHistorique();
  } catch (e) { bouton.disabled = false; bouton.innerHTML = `${ICON.warn} ${t('erreurMot')}`; }
}

// =====================================================================
//  Vue / onboarding / i18n
// =====================================================================
async function rafraichirVue() {
  const clientId = await store.get('clientId');
  const tokens = await lireTokens();
  cacher('carte-onboarding'); cacher('carte-connexion'); cacher('carte-generer');
  if (!clientId) { montrerOnboarding(); return; }
  if (tokens) {
    montrer('carte-connexion'); montrer('carte-generer');
    $('btn-connexion').classList.add('cache');
    $('statut').innerHTML = `<span class="ok">${ICON.check} ${t('connecte')}</span>
      <button class="btn btn-ghost" data-action="deco" style="margin-left:auto; padding:6px 12px">${ICON.signout} ${t('deconnexion')}</button>`;
    await chargerHistorique();
  } else {
    montrer('carte-connexion');
    $('btn-connexion').classList.remove('cache');
    $('statut').innerHTML = `<button class="btn btn-ghost" data-action="reglages" style="padding:6px 12px">${t('reglages')}</button>`;
  }
}

function montrerOnboarding() {
  montrer('carte-onboarding');
  $('onb-redirect').textContent = api.identity.getRedirectURL();
  store.get('clientId').then((id) => { if (id) $('onb-client-id').value = id; });
}

// Notes de notoriété + grisage (mode confidentiel ET exclusivité ambiance/styles)
function majContraintes() {
  const actif = $('pop-actif').checked;
  const niveau = +$('curseur-pop').value;
  const confidentiel = actif && niveau === 1;
  const underground = actif && niveau === 2;
  $('pop-note').textContent = confidentiel ? t('popNoteConfidentiel') : underground ? t('popNoteUnderground') : '';
  // Ambiance et styles sont mutuellement exclusifs (éviter les contradictions).
  const ambianceActive = $('ambiance').value !== '';
  const stylesActifs = $('styles-actif').checked;
  // En confidentiel, on grise aussi époque/explicite ; ambiance/styles se grisent l'un l'autre.
  $('champ-ambiance').classList.toggle('grise', confidentiel || stylesActifs);
  $('champ-styles').classList.toggle('grise', confidentiel || ambianceActive);
  $('champ-epoque').classList.toggle('grise', confidentiel);
  $('champ-explicite').classList.toggle('grise', confidentiel);
}

function appliquerLangue() {
  localStorage.setItem('lang', lang);
  document.documentElement.lang = lang;
  $('lang-fr').classList.toggle('actif', lang === 'fr');
  $('lang-en').classList.toggle('actif', lang === 'en');
  document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll('#ambiance option').forEach((o) => { o.textContent = I18N[lang].ambiances[o.value]; });
  $('affiche-nb').textContent = t('uTitres', $('curseur-nb').value);
  $('affiche-duree').textContent = t('uMin', $('curseur-duree').value);
  $('affiche-histo').textContent = I18N[lang].histoLabels[+$('curseur-histo').value - 1];
  $('affiche-pop').textContent = I18N[lang].popLabels[+$('curseur-pop').value - 1];
  $('affiche-fam').textContent = I18N[lang].famLabels[+$('curseur-fam').value - 1];
  majContraintes();
  if (genresData) { if (!genresData.historique.length) $('chips-historique').innerHTML = `<span class="aide">${t('aucunStyle')}</span>`; renderAutres(); }
  rafraichirVue();
  if (dernierResultat) afficherResultat(dernierResultat);
}

// =====================================================================
//  Câblage des événements (aucun handler inline → conforme MV3)
// =====================================================================
function setMesure(m) {
  mesure = m;
  $('t-nombre').classList.toggle('actif', m === 'nombre');
  $('t-duree').classList.toggle('actif', m === 'duree');
  $('bloc-nombre').classList.toggle('cache', m !== 'nombre');
  $('bloc-duree').classList.toggle('cache', m !== 'duree');
}

function init() {
  // Langue : préférence enregistrée si elle existe, sinon langue du navigateur
  // (français si le navigateur est en FR, anglais par défaut sinon).
  const stored = localStorage.getItem('lang');
  if (stored === 'fr' || stored === 'en') lang = stored;
  else lang = (navigator.language || '').toLowerCase().startsWith('fr') ? 'fr' : 'en';

  $('lang-fr').addEventListener('click', () => { lang = 'fr'; appliquerLangue(); });
  $('lang-en').addEventListener('click', () => { lang = 'en'; appliquerLangue(); });

  $('t-nombre').addEventListener('click', () => setMesure('nombre'));
  $('t-duree').addEventListener('click', () => setMesure('duree'));
  $('curseur-nb').addEventListener('input', (e) => { $('affiche-nb').textContent = t('uTitres', e.target.value); });
  $('curseur-duree').addEventListener('input', (e) => { $('affiche-duree').textContent = t('uMin', e.target.value); });
  $('curseur-histo').addEventListener('input', (e) => { $('affiche-histo').textContent = I18N[lang].histoLabels[+e.target.value - 1]; });
  $('curseur-pop').addEventListener('input', (e) => { $('affiche-pop').textContent = I18N[lang].popLabels[+e.target.value - 1]; majContraintes(); });
  $('pop-actif').addEventListener('change', (e) => {
    $('bloc-pop').classList.toggle('cache', !e.target.checked);
    majContraintes();
  });
  $('styles-actif').addEventListener('change', async (e) => {
    $('bloc-styles').classList.toggle('cache', !e.target.checked);
    majContraintes(); // exclusivité avec l'ambiance
    if (e.target.checked && genresData === null) await chargerGenres();
  });
  $('ambiance').addEventListener('change', majContraintes); // exclusivité avec les styles
  $('explicite-actif').addEventListener('change', (e) => {
    $('bloc-explicite').classList.toggle('cache', !e.target.checked);
  });
  $('btn-voir-plus').addEventListener('click', () => {
    if (autresAffiches < genresData.autres.length) autresAffiches += 20; else autresAffiches = 20;
    renderAutres();
  });
  $('bloc-styles').addEventListener('click', (e) => {
    const chip = e.target.closest('.chip'); if (!chip) return;
    const g = chip.dataset.genre.toLowerCase();
    if (selection.has(g)) { selection.delete(g); chip.classList.remove('selectionne'); }
    else { selection.add(g); chip.classList.add('selectionne'); }
  });

  // Époque : toutes les décennies cochées par défaut
  for (const [, v] of DECENNIES) selectionEpoque.add(v);
  $('chips-epoque').innerHTML = DECENNIES.map(([lab, val]) => `<span class="chip selectionne" data-decennie="${val}">${lab}</span>`).join('');
  $('epoque-actif').addEventListener('change', (e) => {
    $('bloc-epoque').classList.toggle('cache', !e.target.checked);
  });
  $('bloc-epoque').addEventListener('click', (e) => {
    const c = e.target.closest('.chip'); if (!c) return;
    const v = +c.dataset.decennie;
    if (selectionEpoque.has(v)) { selectionEpoque.delete(v); c.classList.remove('selectionne'); }
    else { selectionEpoque.add(v); c.classList.add('selectionne'); }
  });

  // Familiarité
  $('fam-actif').addEventListener('change', (e) => {
    $('bloc-fam').classList.toggle('cache', !e.target.checked);
  });
  $('curseur-fam').addEventListener('input', (e) => { $('affiche-fam').textContent = I18N[lang].famLabels[+e.target.value - 1]; });

  $('btn-generer').addEventListener('click', generer);
  $('btn-connexion').addEventListener('click', login);

  // Onboarding
  $('btn-enregistrer').addEventListener('click', async () => {
    const id = $('onb-client-id').value.trim();
    if (!id) return;
    await store.set('clientId', id);
    await rafraichirVue();
  });
  $('btn-copier').addEventListener('click', () => {
    navigator.clipboard.writeText($('onb-redirect').textContent);
    $('btn-copier').textContent = t('onbCopie');
    setTimeout(() => { $('btn-copier').textContent = t('onbCopier'); }, 1500);
  });

  // Délégation pour le statut, le résultat et l'historique
  $('statut').addEventListener('click', (e) => {
    const b = e.target.closest('[data-action]'); if (!b) return;
    if (b.dataset.action === 'deco') deconnexion();
    else if (b.dataset.action === 'reglages') { cacher('carte-connexion'); montrerOnboarding(); }
  });
  $('carte-resultat').addEventListener('click', (e) => {
    const b = e.target.closest('[data-action]'); if (!b) return;
    if (b.dataset.action === 'suppr-res') supprimer(b.dataset.id, b, true);
    else if (b.dataset.action === 'partager') partager(b.dataset.id, b.dataset.nom, b);
  });
  $('zone-historique').addEventListener('click', (e) => {
    const b = e.target.closest('[data-action]'); if (!b) return;
    const a = b.dataset.action;
    if (a === 'toggle') $('histo-' + b.dataset.idx).classList.toggle('ouvert');
    else if (a === 'restaurer') restaurer(b.dataset.id, b);
    else if (a === 'partager') partager(b.dataset.id, b.dataset.nom, b);
    else if (a === 'suppr') supprimer(b.dataset.id, b, false);
  });

  appliquerLangue();
}

init();
